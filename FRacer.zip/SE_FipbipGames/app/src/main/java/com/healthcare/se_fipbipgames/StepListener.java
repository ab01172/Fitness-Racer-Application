package com.healthcare.se_fipbipgames;

public interface StepListener {

    public void step(long timeNs);

}