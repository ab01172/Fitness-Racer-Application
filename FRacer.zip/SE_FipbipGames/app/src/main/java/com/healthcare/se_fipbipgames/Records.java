package com.healthcare.se_fipbipgames;


import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;


public class Records extends AppCompatActivity implements View.OnClickListener{
    /* Database name */
    public static final String DATABASE_NAME = "mydatabase";

    /* Edit Texts & Spinner, we will use these in views */
    EditText editTextName, editTextAge, editTextHeight, editTextWeight;
    Spinner spinnerGender;

    /* Database variable */
    SQLiteDatabase mDatabase;


    @Override
    protected

    void                    onCreate
            (Bundle
                     savedInstanceState
            )
                                                                                                                                                                                            {
        super.





                onCreate                                            (savedInstanceState);
        setContentView


                (R.layout.activity_records

        );

        /* editText & spinner views */
        editTextName = findViewById(R.id.editTextName);
        editTextAge = findViewById(R.id.editTextAge);
        editTextHeight = findViewById(R.id.editTextHeight);
        editTextWeight = findViewById(R.id.editTextWeight);

        spinnerGender = findViewById(R.id.spinnerGender);

        /* OnClickListener for Save & View */
        findViewById(R.id.buttonSavePersDetails).setOnClickListener(Records.this);
        findViewById(R.id.textViewViewDetails).setOnClickListener(Records.this);

        /* Creating the database */
        mDatabase = openOrCreateDatabase(DATABASE_NAME, MODE_PRIVATE, null);

        createTable();





    }
    //drop table method should be personaldetails NOT mydatabase table name = personaldetails?
    private void createTable() {


        String sql = "CREATE TABLE IF NOT EXISTS personaldetails (\n" +
                " id INTEGER NOT NULL CONSTRAINT personaldetails_pk PRIMARY KEY AUTOINCREMENT, \n" +
                " _fullname String NOT NULL, \n" + // name -- _fullname? maybe works?
                " gender String NOT NULL, \n" +
                " age String NOT NULL, \n" +
                " heightcm String NOT NULL, \n" +
                " weightkg String NOT NULL \n" +
                ");";
        mDatabase.execSQL(sql);

    }
    private void dropTable() {
        String sql = " DROP TABLE 'mydatabase';" + "\n";

        mDatabase.execSQL(sql);

    }
    private void savePersDetails(){
        String _fullname = editTextName.getText().toString().trim(); // name
        String age = editTextAge.getText().toString().trim();
        String height = editTextHeight.getText().toString().trim();
        String weight = editTextWeight.getText().toString().trim();

        String gender = spinnerGender.getSelectedItem().toString();

        if (_fullname.isEmpty()){ // name
            editTextName.setError("Name can't be empty");
            editTextName.requestFocus();
            return;
        }

        if (age.isEmpty()){
            editTextAge.setError("Age can't be empty");
            editTextAge.requestFocus();
            return;
        }

        if (height.isEmpty()){
            editTextHeight.setError("Height can't be empty");
            editTextHeight.requestFocus();
            return;
        }

        if (weight.isEmpty()){
            editTextWeight.setError("Weight can't be empty");
            editTextWeight.requestFocus();
            return;
        }

        String sql = "INSERT INTO personaldetails(_fullname, gender, age, heightcm, weightkg)" + "VALUES (?, ?, ?, ?, ?)";

        mDatabase.execSQL(sql, new String[]{_fullname, gender, age, height, weight}); // name
        Toast.makeText(this, "Your details have been saved", Toast.LENGTH_SHORT).show();

    }


    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.buttonSavePersDetails:

                savePersDetails();

                break;

            case R.id.textViewViewDetails:

                startActivity(new Intent(this, PersonalDetailsActivity.class));
                break;
        }

    }
}
