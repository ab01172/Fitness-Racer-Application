package com.healthcare.se_fipbipgames;

public class PersonalDetails {
    int id;
    String _fullname, gender, age, height, weight; //name

    public PersonalDetails(int id, String _fullname, String gender, String age, String height, String weight){ //name
        this.id = id;
        this._fullname = _fullname; //name
        this.gender = gender;
        this.age = age;
        this.height = height;
        this.weight = weight;
    }

    public int getId(){
        return id;
    }

    public String getName(){
        return _fullname;
    }

    public String getGender(){
        return gender;
    }

    public String getAge() {
        return age;
    }

    public String getHeight(){
        return height;
    }

    public String getWeight() {
        return weight;
    }
}