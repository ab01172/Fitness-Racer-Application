package com.healthcare.se_fipbipgames;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {

    String[] difficulty;
    private Button btn_easy;
    private Button btn_medium;
    private Button btn_hard;
    private ProgressBar progressBar;
    private FirebaseAuth.AuthStateListener authListener;
    private FirebaseAuth auth;
    int chosen_dif;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle(getString(R.string.app_name));
        setSupportActionBar(toolbar);


        //get firebase auth instance
        auth = FirebaseAuth.getInstance();

        //get current user
        final FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

        authListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
                if (user == null) {
                    // user auth state is changed - user is null
                    // launch login activity
                    startActivity(new Intent(MainActivity.this, LoginActivity.class));
                    finish();
                }
            }
        };



        btn_easy=(Button)findViewById(R.id.btn_easy);
        btn_medium=(Button)findViewById(R.id.btn_medium);
        btn_hard=(Button)findViewById(R.id.btn_hard);



        btn_easy.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                chosen_dif = 180;
                Intent intent = new Intent(getBaseContext(), MapsActivity.class);
                intent.putExtra("chosen_dif", chosen_dif);
                startActivity(intent);
            }
        });

        btn_medium.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                chosen_dif = 300;
                Intent intent = new Intent(getBaseContext(), MapsActivity.class);
                intent.putExtra("chosen_dif", chosen_dif);
                startActivity(intent);
            }
        });
        btn_hard.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                chosen_dif = 600;
                Intent intent = new Intent(getBaseContext(), MapsActivity.class);
                intent.putExtra("chosen_dif", chosen_dif);
                startActivity(intent);
            }
        });

        progressBar = (ProgressBar) findViewById(R.id.progressBar);

        if (progressBar != null) {
            progressBar.setVisibility(View.GONE);
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        switch (item.getItemId()) {
            case R.id.option_account:



                Intent intent = new Intent(MainActivity.this, AccountSettings.class);

                startActivity(intent);

                return true;
            case R.id.option_records:
                Intent intent2 = new Intent(getBaseContext(), Records.class);

                startActivity(intent2);

                return true;
            default:
                return super.onOptionsItemSelected(item);
        }


    }

    public void signOut() {
        auth.signOut();
    }

    @Override
    protected void onResume() {
        super.onResume();
        //progressBar.setVisibility(View.GONE);
    }

    @Override
    public void onStart() {
        super.onStart();
        auth.addAuthStateListener(authListener);
    }

    @Override
    public void onStop() {
        super.onStop();
        if (authListener != null) {
            auth.removeAuthStateListener(authListener);
        }
    }


}
