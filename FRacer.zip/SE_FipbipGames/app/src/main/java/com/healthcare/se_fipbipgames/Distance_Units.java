package com.healthcare.se_fipbipgames;

/**
 * Created by student on 03/03/2018.
 */

public enum Distance_Units {
    Meters, Kilometers, None;
}
